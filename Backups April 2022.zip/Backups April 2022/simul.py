import random
import datetime
import time

import agent as agent
from env import *

################################################################ Simulation Parameters / rest are set in the config file
maximum_depth=3
num_of_Mu_chunks=8
setting='d'+str(maximum_depth)+'c'+str(num_of_Mu_chunks)

################################################################ Creating environment and the agent
e=tiger_POMDP_env(read_config=True,config_address='./tiger.json',parameters=None)

ag=agent.Bauerle_Rieder_agent(environment=e, num_of_Mu_chunks=num_of_Mu_chunks,max_iterations=maximum_depth)

################################################################ Pre-planning
t=datetime.datetime.now()
ag.pre_planning_paration(make_and_save_Mu=True)
print('Pre-planning:', datetime.datetime.now()-t)

################################################################ value iteration
t=datetime.datetime.now()

ag.value_iteration(utility_function='risk-neutral',save_results=True,load_results=False,depth_and_chunks=setting)
#ag.value_iteration(utility_function=0.5,save_results=True,load_results=False,depth_and_chunks=setting) # risk-averse
#ag.value_iteration(utility_function=-0.5,save_results=False,load_results=True,depth_and_chunks=setting) # risk-seeking

print('Value iteration:', datetime.datetime.now()-t)




########################################################################################################
############################################    Simulation    ##########################################
########################################################################################################
starting_time=datetime.datetime.now()
num_to_act=dict(zip(list(e.actions.values()),list(e.actions.keys())))

# reset the agent with random starting x and probability of P(y=0 and s=0)=1/3 and P(y=1 and s=0)=2/3
e.reset()
initial_observation=e.current_state
ag.reset(y0_prob=0.5,initiative_observation=initial_observation)
observation=initial_observation
state=e.current_state
print('========================= Simulation satrts =====================')
for t in range(maximum_depth):
    print('====================================================')
    print('t=',t)
    print('------')
    print('state:',state,e.states[state])
    print('observation:',observation)  
    
    action,value,belief_at_action=ag.do_action()   
    t1,t2,state,reward,observation=e.step(num_to_act[action])
    new_mu=ag.update_agent(new_observation=observation)
    
    print('             belief_at_action:')   
    print(belief_at_action)
    
    #print('value_at_action:')
    #print(value)
    print('')
    print('             action:',num_to_act[action])  
    
    
    print ('              **' )
    print('reward:',reward,'new observation:',observation)
    print('')
    print('            new_beliefs:')
    print (new_mu)
    print('====================================================')
print('Value-iteration:', datetime.datetime.now()-starting_time)     
#print('state:',e.current_state,'observation:',ag.current_internal_x )
  